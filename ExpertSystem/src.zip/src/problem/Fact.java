package problem;
import java.util.UUID;

/*
Cette class permet de définir un fait
Un/des fact(s) sera(ont) utilisé(s) dans les rules afin de déterminer si  
la règle est valide ou non. De plus ils seront utilisé dans la base de faits 
pour compléter le problème.
*/

public class Fact {
    
    private String ID;
    private String fact;

    public Fact (String fact) {
        this.fact = fact;
        String uniqueID = UUID.randomUUID().toString();
        this.ID = uniqueID; 
    }

    public String get_id() {
        return this.ID;
    }

    public String get_fact(){
        return this.fact;
    }

    public String toString(){
        return "Fait : " + this.fact;
    }
}

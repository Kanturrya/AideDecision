package chaining;

public interface Resolution {
    public String solver();
}

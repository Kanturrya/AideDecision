package chaining;
import java.util.ArrayList;
import java.util.Map;

import problem.Fact;
import problem.Problem;
import problem.Rule;

import java.util.HashMap;

public class ForwardChaining implements Resolution{

    private Map<Integer, Rule> rules;
    private ArrayList<Fact> factDataBase;

    private Problem problem;

    public ForwardChaining(Problem problem) {

        this.problem = problem;
        this.rules = new HashMap<>(this.problem.getRules());
        this.factDataBase = new ArrayList<>(this.problem.getFactsDataBase());
    }

    public String solver(){
        
        //Si le problème n'a pas de Rules ou que la base de faits est vide
        if(this.rules.isEmpty() || this.factDataBase.isEmpty()){
            return "Forward chaining : No solution found, Empty problem OR Empty facts database";
        }

        //Boucle sur les rules.
        for(var rule : this.rules.entrySet()) {

            //On cherche si les facts de la rule sont tous dans la base de faits
            if(factDataBase.containsAll(rule.getValue().getFacts())) {

                //Si on a la réponse final alors on valide la recherche.
                if(this.factDataBase.contains(this.problem.getFinalAnswer())){
                    return "\nForwardChaining : \nAccepted with facts database : " + this.factDataBase;
                } 

                //Si la réponse de la rule n'est pas dans la base de faits alors je l'ajoute
                if(!this.factDataBase.contains(rule.getValue().getAnswer())){
                    this.factDataBase.add(rule.getValue().getAnswer());
                    this.solver();
                } 
            } 
        }  
        return "Forward chaining : No solution found";
    }
}
